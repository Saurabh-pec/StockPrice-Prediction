-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: cisdemo
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `sl_no` int NOT NULL AUTO_INCREMENT,
  `arpu` bigint NOT NULL,
  `arr` bigint NOT NULL,
  `cac` bigint NOT NULL,
  `cltv` bigint NOT NULL,
  `company_code` bigint NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `fcf` float NOT NULL,
  `gross_margin` float NOT NULL,
  `net_revenue_retention` bigint NOT NULL,
  `no_of_curtomers` bigint NOT NULL,
  `operating_margin` float NOT NULL,
  `payback_period` bigint NOT NULL,
  `profit_margin` float NOT NULL,
  `revenue` float NOT NULL,
  `sales_marketing` bigint NOT NULL,
  `year` int NOT NULL,
  PRIMARY KEY (`sl_no`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (1,0,0,0,0,827384,'abc',26,77,0,0,44,0,50,2,0,2018),(2,0,0,0,0,827384,'abc',76,53,0,0,23,0,50,3,0,2019),(3,0,0,0,0,827384,'abc',39,83,0,0,73,0,50,4,0,2020),(4,0,0,0,0,827384,'abc',56,53,0,0,73,0,50,5,0,2021),(5,0,0,0,0,827384,'abc',70,63,0,0,43,0,50,7,0,2022),(6,0,0,0,0,834652,'ash',0,23,0,0,0,0,0,0,0,2018),(7,0,0,0,0,834652,'ash',0,33,0,0,0,0,0,0,0,2019),(8,0,0,0,0,834652,'ash',0,43,0,0,0,0,0,0,0,2020),(9,0,0,0,0,834652,'ash',0,53,0,0,0,0,0,0,0,2021),(10,0,0,0,0,834652,'ash',0,63,0,0,0,0,0,0,0,2022);
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-22 14:05:30
