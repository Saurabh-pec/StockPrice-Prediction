import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, Tooltip, Legend } from "recharts";

const LineGraph = ({ data }) => {

  const [graphData, setGraphData] = useState([]);

  const getGraphData = () => {
    let year = Object.values(data[0])[0].reduce((arr, items) => {
      arr.push(items.year);
      return arr;
    }, []);

    let ans = [];
    year.forEach((year) => {
      const dataPoint = { year: year.toString() };

      data.forEach((metric) => {
        const metricName = Object.keys(metric)[0];
        const percentage = metric[metricName].find(
          (item) => item.year === year
        ).percentage;
        dataPoint[metricName] = percentage;
      });

      ans.push(dataPoint);
    });

    return ans;
  }

  useEffect(() => {
    if (data.length > 0) {
      setGraphData(() => getGraphData());
    }
  }, [data]);
  
  return (
    <LineChart
      width={170}
      height={160}
      data={graphData}
      margin={{ left: 10, right: 10, top: 5, bottom: 5 }}
    >
      <XAxis dataKey="year" interval={0} tick={{ fontSize: 6 }} />
      <Tooltip />
      <Legend />

      <Line
        type="linear"
        dataKey="Industry Average"
        stroke="#0170AD"
        activeDot={{ r: 8, shape: "square" }}
        dot={{
          stroke: "#0170AD",
          fill: "#0170AD",
          strokeWidth: 2,
          width: 8,
          height: 8,
        }}
      />

      {data.length > 1 && (
        <Line
          type="linear"
          dataKey={Object.keys(data[1])[0]}
          stroke="#D35D85"
          activeDot={{ r: 8, shape: "square" }}
          dot={{
            stroke: "#D35D85",
            fill: "#D35D85",
            strokeWidth: 2,
            width: 8,
            height: 8,
          }}
        />
      )}
    </LineChart>
  );
};

export default LineGraph;