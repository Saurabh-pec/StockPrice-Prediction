import React, { useContext, useEffect, useState } from "react";
// import * as XLSX from "xlsx";
import "../styles/Graph.css";

import YearModal from "./Modal2";
import LineGraph from "./LineGraph";
import CircleGraph from "./CircleGraph";
import { GlobalContext } from "../context/GlobalContext";

const Graph = () => {
  const { graphData, companyDataApi, setCompanyDataApi, company_id } = useContext(GlobalContext);

  const [graphTitle, setGraphTitle] = useState([]);
  const [circleData, setCircleData] = useState({});
  const [lineData, setLineData] = useState([]);
  const [selectedTitle, setSelectedTitle] = useState("");
  const [openYearModal, setOpenYearModal] = useState(false);
  const [fileSelected, setFileSelected] = useState(false);

  const getTitleData = () => {
    let title = [];

    if (Object.keys(graphData).length > 0) {
      title = Object.keys(graphData.metrics);
    }

    return title;
  };

  const getCirlceData = () => {
    let circle = {};

    if (Object.keys(graphData).length > 0) {
      circle = Object.keys(graphData.metrics).reduce((obj, curr) => {
        let key = curr;
        let name = graphData.industryName;
        let average = graphData.metrics[curr].average;

        obj[key] = [{ [name]: average }];
        return obj;
      }, {});

      if (companyDataApi && companyDataApi.metrics) {
        Object.keys(circle).forEach((item) => {
          if (
            companyDataApi.metrics[item] &&
            companyDataApi.metrics[item].average
          ) {
            circle[item].push({
              [companyDataApi.industryName]:
                companyDataApi.metrics[item].average,
            });
          }
        });
      }
    }

    return circle;
  };

  const getLineData = () => {
    let line = {};

    if (Object.keys(graphData).length > 0) {
      line = Object.keys(graphData.metrics).reduce((obj, curr) => {
        let key = curr;
        let value = Object.entries(
          graphData.metrics[curr].yearData
        ).reduce((arr, [year, percentage]) => {
          arr.push({ year, percentage });
          return arr;
        }, []);

        obj[key] = [{ [graphData.industryName]: value }];
        return obj;
      }, {});

    if (companyDataApi && companyDataApi.metrics) {
      Object.keys(line).forEach((item) => {
        if (
          companyDataApi.metrics[item] &&
          companyDataApi.metrics[item].financialMetrics["yearData"]
        ) {
          line[item].push({
            [companyDataApi.industryName]: Object.entries(
              companyDataApi.metrics[item].financialMetrics["yearData"]
            ).map(([year, value]) => {
              return {
                year: year,
                percentage: value,
              };
            }),
          });
        }
      });
    }
  }

    return line;
  };

  const handleFileChange = (event) => {
    // console.log("Indisde the function")
    // const file = event.target.files[0];
    // if (file) {
    //   setFileSelected(true);

    //   const reader = new FileReader();

    //   reader.onload = (e) => {
    //     const data = e.target.result;
    //     const workbook = XLSX.read(data, { type: "binary" });
    //     const sheetName = workbook.SheetNames[0];
    //     const sheet = workbook.Sheets[sheetName];
    //     const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });

    //     console.log("Parsed JSON data:", jsonData);
    //   };

    //   reader.readAsBinaryString(file);
    // } else {
    //   setFileSelected(false);
    // }
  };

  // console.log("GraphData: ", graphData);
  // console.log("Title: ", graphTitle);
  // console.log("graph company: ", companyDataApi);
  // console.log("graph circle: ", circleData);
  // console.log("graph line: ", lineData);

  useEffect(() => {
    if (graphData !== undefined) {
      setGraphTitle(() => getTitleData());
      setCircleData(() => getCirlceData());
      setLineData(() => getLineData());
    }
  }, [graphData, companyDataApi]);

  return (
    <div className="graph">
      <div className="subscription-dropdown">
        <div className="title-dropdown">
          <p>Capgemini Subscription Index</p>
          <select name="dashboard-options" className="dashboard-options">
            <option value="Revenue">Revenue View</option>
            <option value="Growth">Growth View</option>
            <option value="Acquisition">Acquisition View</option>
            <option value="Retention">Retention View</option>
          </select>
        </div>

        <div className="excel">
          <label htmlFor="file-upload">
            <img src="/images/excel.png" alt="" />{" "}
            <span>
              {fileSelected
                ? "Edit your employee data"
                : "Add your company data"}
            </span>
          </label>
          <input
            type="file"
            id="file-upload"
            accept=".xls, .xlsx"
            style={{ display: "none" }}
            onChange={handleFileChange}
          />
          {fileSelected && (
            <span className="clear-data" onClick={() => setFileSelected(false)}>
              <img src="/images/cross.png" alt="cross.png" />
              Clear your employee data
            </span>
          )}
        </div>
      </div>

      <div className="circle-graph">
        <div className="info">
          <span className="info-icon">:::</span>
          <span>Overall average based on years(s) selected</span>
        </div>
        <div className="graph-main-box">
          {graphTitle.map((title, index) => (
            <div key={index} className="graph-box">
              <div className="title-bar">
                <span>{title}</span>
                <img
                  src="/images/add.png"
                  onClick={() => {
                    setOpenYearModal(true);
                    setSelectedTitle(title);
                  }}
                  alt="add.png"
                />
                {openYearModal && (
                  <YearModal
                    key={index}
                    heading={selectedTitle}
                    companyDataApi={companyDataApi}
                    setCompanyDataApi={setCompanyDataApi}
                    company_id={company_id}
                    closeYearModal={setOpenYearModal}
                  />
                )}
              </div>
              <div className="graph-model">
                <CircleGraph data={circleData[title]} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="line-graph">
        <div className="info">
          <span className="info-icon">:::</span>
          <span>Year Wise Trend</span>
        </div>
        <div className="graph-main-box">
          {graphTitle.map((title, index) => (
            <div key={index} className="graph-box">
              <div className="title-bar">
                <span>{title}</span>
                <img
                  src="/images/add.png"
                  onClick={() => {
                    setOpenYearModal(true);
                    setSelectedTitle(title);
                  }}
                  alt="add.png"
                />
              </div>
              <div className="graph-model">
                <LineGraph data={lineData[title]} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="copy-right">
        &copy; Capgemini, {new Date().getFullYear()}. All rights reserved.
      </div>
    </div>
  );
};

export default Graph;
