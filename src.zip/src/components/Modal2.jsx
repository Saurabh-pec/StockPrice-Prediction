import React, { useContext, useState } from "react";
import { RiFolderAddLine } from "react-icons/ri";

import "../styles/Modal.css";
import axios from "axios";
import { GlobalContext } from "../context/GlobalContext";

const YearModal = ({
  closeYearModal, heading,
  companyDataApi, setCompanyDataApi, company_id,
}) => {

  const { ApiData } = useContext(GlobalContext);
  const year = ApiData.years;

  const getCompanyName = () => {
    let name = "";

    if(Object.keys(companyDataApi).length > 0) {
      name = companyDataApi.industryName;
    }

    return name;
  };

  const clear = () => {
    let yearObj = {};
  
    year.forEach(item => {
      yearObj[item] = "";
    });
  
    return yearObj;
  };

  const getYearPercentages = () => {
    let yearObj = {};  
    year.forEach(item => {
      yearObj[item] = 0;
    });

    if(Object.keys(companyDataApi).length > 0) {
      if(heading === 'fcf') {
        yearObj = companyDataApi.metrics[heading].financialMetrics["fcf"];
      }
      else {
        yearObj = companyDataApi.metrics[heading].financialMetrics["yearData"];
      }
    }
  
    return yearObj;
  };

  const getRevenuePercentages = () => {
    let yearObj = {};
    year.forEach(item => {
      yearObj[item] = 0;
    });

    if(Object.keys(companyDataApi).length > 0) {
      yearObj = companyDataApi.metrics[heading].financialMetrics["revenue"];
    }

    return yearObj;
  };
  

  const [showErrorModal, setShowErrorModal] = useState(false);
  const [companyName, setCompanyName] = useState(getCompanyName());
  const [yearPercentages, setYearPercentages] = useState(getYearPercentages());
  const [revenuePercentages, setRevenuePercentages] = useState(getRevenuePercentages());

  const handleMargin = (event, year) => {
    const { value } = event.target;
    setYearPercentages({
      ...yearPercentages,
      [year]: value,
    });
  };

  const handleRevenue = (event, year) => {
    const { value } = event.target;
    setRevenuePercentages({
      ...revenuePercentages,
      [year]: value,
    });
  };

  const handleCompanyNameChange = (event) => {
    setCompanyName(event.target.value);
  };

  const handleModalClose = () => {
    setShowErrorModal(false);
  };

  const handleOnSubmit = (event) => {
    event.preventDefault();

    const allPercentagesFilled = Object.values(yearPercentages).every(
      (percentage) => percentage !== 0
    );

    let companyData = {}
    let updatedCompanyDataApi = {};

    if(heading === 'fcf') {
      companyData = {
        companyCode: company_id,
        companyName,
        marginName: heading,
        financialMetrics: {
          yearData:  yearPercentages,
          revenue: revenuePercentages
        }
      }

      const getAverageFcF = (values1, values2, keys) => {
        let obj = {
          average: 0,
          yearData: {}
        };
        let sum = 0;
        let year = {};
      
        for(let i=0; i<values1.length; i++) {
          sum += ((+values1[i]) / (+values2[i]));
          year[keys[i]] = ((+values1[i]) / (+values2[i]));
        }
        obj.average = (sum/values1.length).toFixed(2);
        obj.yearData = year;
        
        return obj;
      }
      
      let obj = getAverageFcF(Object.values(companyData.financialMetrics.yearData),
                  Object.values(companyData.financialMetrics.revenue), 
                  Object.keys(companyData.financialMetrics.revenue));
      
      let financeMetrics = {}
      
      financeMetrics["yearData"] = obj.yearData;
      financeMetrics["fcf"] = companyData.financialMetrics.yearData;
      financeMetrics["revenue"] = companyData.financialMetrics.revenue;
      
      updatedCompanyDataApi = Object.assign({}, companyDataApi);
      updatedCompanyDataApi.metrics[companyData.marginName].average = obj.average;
      updatedCompanyDataApi.metrics[companyData.marginName].financialMetrics = financeMetrics;
    } else {
      companyData = {
        companyCode: company_id,
        companyName,
        marginName: heading,
        financialMetrics: {
          yearData:  yearPercentages
        }
      }

      const getAverage = (values) => {
          let average = values.reduce((sum, item) => {
              sum+= (+item)
              return sum;
          }, 0)
          return (average/values.length).toFixed(2);
      }

      updatedCompanyDataApi = Object.assign({}, companyDataApi);
      updatedCompanyDataApi.metrics[companyData.marginName].average = getAverage(Object.values(companyData.financialMetrics.yearData));
      updatedCompanyDataApi.metrics[companyData.marginName].financialMetrics = companyData.financialMetrics;
    }

    axios.post(`http://localhost:8080/cv/revenue`, companyData)
         .then(() => {
          console.log("Entered")
         })
         .catch(err => {
          console.log(err);
         })

    console.log(updatedCompanyDataApi);
    setCompanyDataApi(updatedCompanyDataApi);
    closeYearModal(false);
  };

  return (
    <>
      <div className="modalBackground">
        <div className="modalContainer">
          <div className="close" onClick={() => closeYearModal(false)}>
            X
          </div>
          <div className="title">
            <span>{<RiFolderAddLine />}</span>
            <p>Add data for {heading}</p>
          </div>

          <form onSubmit={handleOnSubmit}>
            <label htmlFor="company-name">Company name</label>
            <input
              id="company-name"
              type="text"
              required={true}
              placeholder="Add your company name here"
              value={companyName}
              onChange={handleCompanyNameChange}
            />
            <label htmlFor="company-data">Please enter company data:</label>

            <div className="data-section">
              <div className="para-conatiner">
                <p>{heading}</p>
                {(heading === 'fcf') && <p>Revenue</p>}
              </div>
              <div className="container">
                {year.map((item) => {
                  return (
                    <div className="input-section" key={item}>
                      <span>{item}</span>
                      <input
                        id="company-data"
                        name={item}
                        type="number"
                        placeholder="X%"
                        value={yearPercentages[item]}
                        onChange={(e) => handleMargin(e, item)}
                      />
                      {
                        (heading === 'fcf') && <input
                        id="company-data"
                        name={item}
                        type="number"
                        placeholder="X%"
                        value={revenuePercentages[item]}
                        onChange={(e) => handleRevenue(e, item)}
                      />
                      }
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="button-section">
              <span onClick={() => {
                setYearPercentages(clear())
                setRevenuePercentages(clear())
                setCompanyName("")
              }}>Clear</span>
              <input type="submit" value="Submit" />
            </div>
          </form>
        </div>
      </div>

      {showErrorModal && (
        <div className="modalBackground">
          <div className="modalContainer">
            <p className="disclaimer-title">Disclaimer</p>
            <p className="disclaimer-content">
              To ensure accurate comparison between your company's performance
              and industry benchmarks, please provide data for all 5 years.
              Incomplete entries will limit your company's graph to only entered
              years.
            </p>
            <div className="button-section">
              <button onClick={handleModalClose}>Go back</button>
              <button onClick={handleModalClose}>Continue</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default YearModal;