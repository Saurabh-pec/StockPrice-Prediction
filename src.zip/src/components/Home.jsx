import React from 'react'
import Filter from './Filter';

import Header from '../components/Header';
import Graph from './Graph';

const Home = () => {
  return (
    <div className='main-container'>
      <Header />
      <div className="graph-filter">
          <Graph />
          <Filter />
      </div>
    </div>
  );
}

export default Home;
