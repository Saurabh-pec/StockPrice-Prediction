import React, { useState } from "react";
import { Link } from "react-router-dom";

import '../styles/Sidebar.css';

const SideBarDropContents = [
  ["/", "/images/revenue.png", "Revenue"],
  ["/", "/images/growth.png", "Growth"],
  ["/", "/images/acquisition.png", "Acquisition"],
  ["/", "/images/retention.png", "Retention"],
];

const SideBarContents = [
  ["/images/insights.png", "Insights"],
  ["/images/subscription.png", "Subscription News"],
  [
    "/images/capgemini_subscriptions_capabilities.png",
    "Capgemini Subscription Capabilities",
  ],
  ["/images/success.png", "Success Stories"],
  ["/images/about_us.png", "About Us"],
  ["/images/contact_us.png", "Contact Us"],
  ["/images/logout.png", "Log out"],
];

const Sidebar = () => {

    const[drop, setDrop] = useState(true);
    const[toggle, setToggle] = useState(true);

    function handleClick () {
      setDrop(!drop);
    }

    function handleToggle() {
      setToggle(!toggle);
      setDrop(true);
    }
    
    return (
      <aside className={`sidebar ${toggle ? "expanded" : "collapsed"}`}>
        <div className="logo-image">
          <img
            src={toggle ? "/images/CG.png" : "/images/capgemini-logo.png"}
            alt="company-logo"
          />
        </div>

        <div className="text">
          <h5 onClick={handleClick}>
            <img
              src="/images/dashboard.png"
              alt="dashboard.png"
              className="icon"
            />
            <span>Dashboard</span>
          </h5>
          {drop && (
            <ul>
              {SideBarDropContents.map((item, index) => {
                return (
                  <li key={index} className="list-item">
                    <Link to={item[0]}>
                      <div className="hover-indicator"></div>
                      <div className="icon-text">
                        <img
                          src={item[1]}
                          alt={item[0] + ".png"}
                          className="icon"
                        />
                        <span>{item[2]}</span>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}

          {SideBarContents.map((item, index) => {
            if (index === 3) {
              return (
                <div key={index} className="horizontal">
                  <h5>
                    <img
                      src={item[0]}
                      alt={item[1] + ".png"}
                      className="icon"
                    />
                    <span>{item[1]}</span>
                  </h5>
                  <hr className="horizontal-bar" />
                </div>
              );
            }
            return (
              <h5 key={index}>
                <img
                 src={item[0]} 
                 alt={item[1] + ".png"} 
                 className="icon" 
                />
                <span>{item[1]}</span>
              </h5>
            );
          })}
        </div>

        <div className="toggle-circle" onClick={handleToggle}>
          <p className="toggler">{toggle ? "<" : ">"}</p>
        </div>
      </aside>
    );
};

export default Sidebar;