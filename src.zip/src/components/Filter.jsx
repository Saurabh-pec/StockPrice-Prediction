import React, { useContext, useState } from "react";
import MultiRangeSlider from "multi-range-slider-react";
import axios from "axios";
import { GlobalContext } from "../context/GlobalContext";

import "../styles/Filter.css";
import "../styles/colors.css";

const Filter = () => {
  const { setGraphData, getFilterData, ApiData } = useContext(GlobalContext);

  const [data, setData] = useState(getFilterData());
  const [minValue, set_minValue] = useState(ApiData.years[0]);
  const [maxValue, set_maxValue] = useState(
    ApiData.years[ApiData.years.length - 1]
  );
  const [toggle, setToggle] = useState(false);

  const getApiData = (newData) => {
    let filterData = {
      maturity: newData.maturity.reduce((arr, item) => {
        Object.entries(item)[0][1] === true &&
          arr.push(Object.entries(item)[0][0]);
        return arr;
      }, []),

      sector: newData.sector.reduce((arr, item) => {
        Object.entries(item)[0][1] === true &&
          arr.push(Object.entries(item)[0][0]);
        return arr;
      }, []),

      years: newData.years,

      industry: newData.industry.reduce((arr, item) => {
        Object.entries(item)[0][1] === true &&
          arr.push(Object.entries(item)[0][0]);
        return arr;
      }, []),
    };

    console.log(filterData);

    const industriesEncoded = filterData.industry.map(industry => encodeURIComponent(industry)).join(",");
    const url = `http://localhost:8080/iv/revenue?maturity=${filterData.maturity.join(",")}
                 &sector=${filterData.sector.join(",")}
                 &year=${filterData.years.join(",")}
                 &industry=${industriesEncoded}`

    axios
      .get(url)
      .then((res) => {
        console.log(url)
        setGraphData(res.data);
        console.log(res.data);
      })
      .catch((error) => {
        console.error("Error occurred:", error);
      });
  };

  const handleInput = (e) => {
    if (minValue !== e.minValue) {
      set_minValue(e.minValue);
    } else {
      set_maxValue(e.maxValue);
    }
    handleYearChange(e.minValue, e.maxValue);
  };

  const handleYearChange = (newMinValue, newMaxValue) => {
    if (newMinValue !== minValue || newMaxValue !== maxValue) {
      const newData = { ...data };
      newData.years = ApiData.years.filter(
        (year) => year >= newMinValue && year <= newMaxValue
      );
      setData(newData);
      getApiData(newData);
    }
  };

  const countTrue = (category) => {
    let count = data[category].reduce((total, curr) => {
      if (Object.values(curr)[0]) {
        total += 1;
      }
      return total;
    }, 0);
    return count;
  };

  const checkValue = (category, value) => {
    let present = data[category].find((item) => {
      if (Object.entries(item)[0][0] === value) {
        return true;
      }
      return false;
    });
    return Object.values(present)[0];
  };

  const handleData = (category, value) => {
    if (
      countTrue(category) > 1 ||
      (countTrue(category) === 1 && !checkValue(category, value))
    ) {
      const newData = { ...data };
      newData[category] = newData[category].map((item) => {
        if (Object.keys(item)[0] === value) {
          item[value] = !item[value];
        }
        return item;
      });
      setData(newData);
      getApiData(newData);
    }
  };

  const handleToggle = () => {
    setToggle(!toggle);
  };

  const handleToggleIcon = () => {
    setToggle(false);
  };

  return (
    <div className={`filter ${toggle ? "narrow" : ""}`}>
      <h4>
        <p onClick={handleToggleIcon}>
          <img src="/images/filter.png" alt="filter.png" />
          <span>Filters</span>
        </p>
        <div className="toggle-circle" onClick={handleToggle}>
          <p className="toggler">{!toggle && ">"}</p>
        </div>
      </h4>

      <hr />

      <div className="filter-box">
        <div className="filter-heading">
          <img
            src="/images/maturity.png"
            onClick={handleToggleIcon}
            alt="maturity.png"
          />{" "}
          <span>Maturity</span>
        </div>
        <div className="filter-content">
          {data.maturity.map((item, index) => (
            <span
              key={index}
              className={Object.values(item)[0] ? "selected" : "not-selected"}
              onClick={() => handleData("maturity", Object.keys(item)[0])}
            >
              {Object.keys(item)[0]}
            </span>
          ))}
        </div>
      </div>

      <div className="filter-box">
        <div className="filter-heading">
          <img
            src="/images/sector.png"
            onClick={handleToggleIcon}
            alt="sector.png"
          />{" "}
          <span>Sector</span>
        </div>
        <div className="filter-content">
          {data.sector.map((item, index) => (
            <span
              key={index}
              className={Object.values(item)[0] ? "selected" : "not-selected"}
              onClick={() => handleData("sector", Object.keys(item)[0])}
            >
              {Object.keys(item)[0]}
            </span>
          ))}
        </div>
      </div>

      <div className="filter-box">
        <div className="filter-heading">
          <img
            src="/images/year.png"
            onClick={handleToggleIcon}
            alt="year.png"
          />{" "}
          <span>Year</span>
        </div>
        <div className="filter-content-year">
          <MultiRangeSlider
            className="year-slider"
            barLeftColor="white"
            barRightColor="white"
            barInnerColor="#0270AE"
            thumbLeftColor="#fff"
            thumbRightColor="#0270AE"
            ruler="false"
            min={ApiData.years[0]}
            max={ApiData.years[ApiData.years.length - 1]}
            step={1}
            minValue={minValue}
            maxValue={maxValue}
            onInput={(e) => {
              handleInput(e);
            }}
          />
        </div>
      </div>

      <div className="filter-box">
        <div className="filter-heading">
          <img
            src="/images/industry.png"
            onClick={handleToggleIcon}
            alt="industry.png"
          />{" "}
          <span>Industry</span>
        </div>
        <div className="filter-content-industry">
          {data.industry.map((item, index) => (
            <span
              key={index}
              className={Object.values(item)[0] ? "selected" : "not-selected"}
              onClick={() => handleData("industry", Object.keys(item)[0])}
            >
              {Object.keys(item)[0]}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Filter;
