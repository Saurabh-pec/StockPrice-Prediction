import React, { useState, useEffect } from "react";
import ReactApexChart from "react-apexcharts";

const CircleGraph = ({ data }) => {
  const [labels, setLabels] = useState([]);
  const [average, setAverage] = useState([]);
  const [isHovering, setIsHovering] = useState(false);
  const [options, setOptions] = useState(null);

  const getLabelsAndAverage = () => {
    let labels = [];
    let average = [];

    data.forEach((item) => {
      const label = Object.keys(item)[0];
      const avg = Object.values(item)[0];

      labels.push(label);
      average.push(avg);
    });

    return { labels, average };
  };

  useEffect(() => {
    if (data.length > 0) {
      const { labels, average } = getLabelsAndAverage();
      setLabels(labels);
      setAverage(average);
    }
  }, [data]);

  useEffect(() => {
    if (labels.length > 0 && average.length > 0) {
      setOptions(getInitialOptions());
    }
  }, [labels, average]);

  function getInitialOptions() {
    return {
      chart: {
        height: 390,
        type: "radialBar",
      },
      plotOptions: {
        radialBar: {
          offsetY: 0,
          startAngle: 0,
          endAngle: 360,
          hollow: {
            margin: 5,
            size: (labels.length > 1) ? "30%" : "40%",
            background: "transparent",
            image: undefined,
          },
          dataLabels: {
            name: {
              show: false,
            },
            value: {
              show: false,
            },
          },
        },
      },
      colors: ["#59B2DC", "#D35D85"],
      labels: labels,
      legend: {
        show: true,
        floating: true,
        fontSize: "8px",
        position: "left",
        offsetX: -20,
        offsetY: (labels.length > 1) ? -15 : -5,
        labels: {
          show: isHovering,
          useSeriesColors: true,
        },
        formatter: function (seriesName, opts) {
          return seriesName + ":  " + opts.w.globals.series[opts.seriesIndex];
        },
        itemMargin: {
          vertical: 0,
          horizontal: 0,
        },
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            legend: {
              show: false,
            },
          },
        },
      ],
    };
  }

  return (
    <div
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <div id="chart">
        {options && (
          <ReactApexChart
            options={options}
            series={average}
            type="radialBar"
            height={220}
          />
        )}
      </div>
      <div id="html-dist"></div>
    </div>
  );
};

export default CircleGraph;
