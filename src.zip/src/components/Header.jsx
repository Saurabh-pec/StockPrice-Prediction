import React from 'react'
import '../styles/Header.css'

import { BsChevronDown } from "react-icons/bs";
import { FaGlobe } from 'react-icons/fa';

const Header = () => {
  return (
    <div className="header">
      <div>
        <h3>Welcome, Matthew</h3>
        <p>Here's your gateway to XaaS industry benchmark</p>
      </div>

      <div className="profile">
        <p className='globe'>{<FaGlobe/>}</p>
        <div className="profile-photo">
          <img src="" alt="" />
        </div>
        <span>Matthew, Parker</span>
        <span className='icon'>{<BsChevronDown />}</span>
      </div>
    </div>
  );
}

export default Header;