import React, { useState } from "react";
import { RiFolderAddLine } from "react-icons/ri";

import "../styles/Modal.css";
import axios from "axios";

const YearModal = ({
  type, closeYearModal, heading, year,
  companyDataApi, setCompanyDataApi, user_id,
}) => {

  console.log("YearModal: ", year);

  const getCompanyName = () => {
    let name = "xyz";

    return name;
  };

  const getYearPercentages = () => {
    let yearObj = {};
  
    year.forEach(item => {
      yearObj[item] = "23";
    });
  
    return yearObj;
  };
  

  const [showErrorModal, setShowErrorModal] = useState(false);
  const [companyName, setCompanyName] = useState(getCompanyName());
  const [yearPercentages, setYearPercentages] = useState(getYearPercentages());

  const handleInputChange = (event, year) => {
    const { value } = event.target;
    setYearPercentages({
      ...yearPercentages,
      [year]: value,
    });
  };

  const handleCompanyNameChange = (event) => {
    setCompanyName(event.target.value);
  };

  const handleModalClose = () => {
    setShowErrorModal(false);
  };

  const handleOnSubmit = (event) => {
    event.preventDefault();

    const allPercentagesFilled = Object.values(yearPercentages).every(
      (percentage) => percentage.trim() !== ""
    );

    const companyData = {
      companyName,
      marginName: heading,
      yearData:  yearPercentages
    }

    console.log(allPercentagesFilled);
    console.log(companyData)

    // closeYearModal(false);
  };

  return (
    <>
      <div className="modalBackground">
        <div className="modalContainer">
          <div className="close" onClick={() => closeYearModal(false)}>
            X
          </div>
          <div className="title">
            <span>{<RiFolderAddLine />}</span>
            <p>Add data for {heading}</p>
          </div>

          <form onSubmit={handleOnSubmit}>
            <label htmlFor="company-name">Company name</label>
            <input
              id="company-name"
              type="text"
              required={true}
              placeholder="Add your company name here"
              value={companyName}
              onChange={handleCompanyNameChange}
            />
            <label htmlFor="company-data">Please enter company data:</label>

            <div className="data-section">
              <p>{heading}</p>
              <div className="container">
                {year.map((item) => {
                  return (
                    <div className="input-section" key={item}>
                      <span>{item}</span>
                      <input
                        id="company-data"
                        name={item}
                        type="text"
                        placeholder="X%"
                        value={yearPercentages[item]}
                        onChange={(e) => handleInputChange(e, item)}
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="button-section">
              <span onClick={() => closeYearModal(false)}>Cancel</span>
              <input type="submit" value="Submit" />
            </div>
          </form>
        </div>
      </div>

      {showErrorModal && (
        <div className="modalBackground">
          <div className="modalContainer">
            <p className="disclaimer-title">Disclaimer</p>
            <p className="disclaimer-content">
              To ensure accurate comparison between your company's performance
              and industry benchmarks, please provide data for all 5 years.
              Incomplete entries will limit your company's graph to only entered
              years.
            </p>
            <div className="button-section">
              <button onClick={handleModalClose}>Go back</button>
              <button onClick={handleModalClose}>Continue</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default YearModal;