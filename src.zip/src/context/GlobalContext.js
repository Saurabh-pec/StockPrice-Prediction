import React from 'react';

import axios from "axios";
import { createContext, useState, useEffect } from "react";

export const GlobalContext = createContext();

export const GlobalProvider = ({children}) => {

    const [graphData, setGraphData] = useState({});
    const [companyDataApi, setCompanyDataApi] = useState({});

    const company_id = 827384;

    const ApiData = {
      maturity: ["High", "Medium", "Low"],
      sector: ["B2B", "B2B/B2C", "B2C"],
      years: [2018, 2019, 2020, 2021, 2022],
      industry: [
        "Advertising Agencies",
        "Education & Training Services",
        "Health Information Services",
        "Information Technology Services",
        "Internet Content & Information",
        "Leisure",
        "Software-Application",
        "Software-Infrastructure",
      ],
    };
  
    const getFilterData = () => {
      let data = {
        maturity: ApiData.maturity.map((item) => ({ [item]: true })),
        sector: ApiData.sector.map((item) => ({ [item]: true })),
        years: [...ApiData.years],
        industry: ApiData.industry.map((item) => ({ [item]: true })),
      };
  
      return data;
    };

    useEffect(() => {
      axios
        .get("http://localhost:8080/iv/revenue")
        .then((res) => {
          console.log("context industry: ", res.data);
          if (res.data !== undefined) {
            setGraphData(res.data);
          }
        })
        .catch((error) => {
          console.error("Error occurred:", error);
        });

      axios
        .get(`http://localhost:8080/cv/revenue?id=${company_id}`)
        .then((res) => {
          console.log("context company", res.data);
          if (res.data !== undefined) {
              console.log("company data from spring: ", res.data);
              setCompanyDataApi(res.data);
          }
        });
    }, []);

    return (
      <GlobalContext.Provider
        value={{
          company_id,
          ApiData,
          graphData,
          setGraphData,
          companyDataApi,
          setCompanyDataApi,
          getFilterData
        }}
      >
        {children}
      </GlobalContext.Provider>
    );
}