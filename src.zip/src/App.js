import React from 'react';

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Suspense, lazy } from 'react';
import Loader from './components/Loader';
import { GlobalProvider } from './context/GlobalContext';

const Dashboard = lazy(() => import("./page/Dashboard"));

function App() {
  return (
    <Router>
      <Suspense fallback={<Loader />}>
        <GlobalProvider>
          <Routes>
            <Route path="/" element={<Dashboard />} />
          </Routes>
        </GlobalProvider>
      </Suspense>
    </Router>
  );
}

export default App;