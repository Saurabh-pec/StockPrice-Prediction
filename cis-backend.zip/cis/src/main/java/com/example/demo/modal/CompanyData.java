package com.example.demo.modal;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompanyData {
	private long companyCode;
	private String companyName;
	private String marginName;
    private Map<String, Map<Integer, Float>> financialMetrics;
}
