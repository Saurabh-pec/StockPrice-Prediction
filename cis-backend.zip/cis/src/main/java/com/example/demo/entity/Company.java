package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "company")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Company {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sl_no ;
	private long companyCode;
	private String companyName;
	private int year;
	private float gross_margin;
	private float operating_margin;
	private float profit_margin;
	private float revenue;
	private float fcf;
	private long arr;
	private long no_of_curtomers;
	private long arpu;
	private long sales_marketing;
	private long cac;
	private long cltv;
	private long payback_period;
	private long net_revenue_retention;
}
