package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entity.Industry;

public interface IndustryRepo extends JpaRepository<Industry, Integer>{
	
	List<Industry> findByTicker(String ticker);

	@Query("SELECT " +
            "ROUND(AVG(subquery.gr"
            + "ossMarginAverage), 2) AS totalGrossmarginAverage, " +
            "ROUND(AVG(subquery.operatingMarginAverage), 2) AS totalOperationAverage, " +
            "ROUND(AVG(subquery.profitMarginAverage), 2) AS totalProfitAverage, " +
            "ROUND(AVG(subquery.fcfMarginAverage), 2) AS totalFCF " +
        "FROM " +
            "(SELECT " +
                "AVG(i.gross_margin) AS grossMarginAverage, " +
                "AVG(i.operating_margin) AS operatingMarginAverage, " +
                "AVG(i.profit_margin) AS profitMarginAverage, " +
                "AVG(i.fcf) AS fcfMarginAverage " +
            "FROM " +
                "Industry i " +
                "WHERE (:maturity IS NULL OR i.maturity IN :maturity) " +
                "AND (:sector IS NULL OR i.sector IN :sector) " +
                "AND (:industries IS NULL OR i.industries IN :industries) " +
                "AND (:year IS NULL OR i.year IN :year) " +
            "GROUP BY " +
                "i.year) AS subquery")
	List<Object[]> calculateTotalAverages(@Param("maturity") List<String> maturity, 
            @Param("sector") List<String> sector, 
            @Param("industries") List<String> industries,
            @Param("year") List<Integer> year);
	
	
	@Query("SELECT i.year, " +
            "ROUND(AVG(i.gross_margin), 2) AS grossmargin_average, " +
            "ROUND(AVG(i.operating_margin), 2) AS operatingmargin_average, " +
            "ROUND(AVG(i.profit_margin), 2) AS profitmargin_average, " +
            "ROUND(AVG(i.fcf), 2) AS fcfmargin_average " +
            "FROM Industry i " +
            "WHERE (:maturity IS NULL OR i.maturity IN :maturity) " +
            "AND (:sector IS NULL OR i.sector IN :sector) " +
            "AND (:industries IS NULL OR i.industries IN :industries) " +
            "AND (:year IS NULL OR i.year IN :year) " +
            "GROUP BY i.year")
	List<Object[]> getIndustryStatistics(@Param("maturity") List<String> maturity, 
                                     @Param("sector") List<String> sector, 
                                     @Param("industries") List<String> industries,
                                     @Param("year") List<Integer> year);

	
	
	
}