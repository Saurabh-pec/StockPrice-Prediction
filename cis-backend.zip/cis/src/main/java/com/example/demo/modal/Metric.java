package com.example.demo.modal;

import java.util.Map;

public class Metric {
    private double average;
    private Map<Integer, Double> yearData;

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }

    public Map<Integer, Double> getYearData() {
        return yearData;
    }

    public void setYearData(Map<Integer, Double> yearData) {
        this.yearData = yearData;
    }
}