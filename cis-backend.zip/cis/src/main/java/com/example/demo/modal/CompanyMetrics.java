package com.example.demo.modal;

import java.util.Map;

public class CompanyMetrics {
	private double average;
	private Map<String, Map<Integer, Double>> financial_metrics;

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }

    public Map<String, Map<Integer, Double>> getFinancialMetrics() {
        return financial_metrics;
    }

    public void setFinancialMetrics(Map<String, Map<Integer, Double>> metrics) {
        this.financial_metrics = metrics;
    }
}
