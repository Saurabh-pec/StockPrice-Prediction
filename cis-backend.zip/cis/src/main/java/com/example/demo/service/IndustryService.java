package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Industry;
import com.example.demo.modal.IndustryMetrics;
import com.example.demo.modal.Metric;
import com.example.demo.repository.IndustryRepo;

@Service
public class IndustryService {
	
	@Autowired
	private IndustryRepo industryRepository;
	
	public Industry getIndustryByTicker(String ticker) {
	    List<Industry> industries = industryRepository.findByTicker(ticker);
	    if (!industries.isEmpty()) {
	        return industries.get(0); 
	    } else {
	        return null; 
	    }
	}
	
	public IndustryMetrics getIndustryStatistics(List<String> maturity, 
            									List<String> sector, 
            									List<String> industries,
            									List<Integer> year) {
		String[] metricNames = { "Gross Margin", "Operating Margin", "Profit Margin", "fcf" };
		List<Object []> yearWiseAverage = industryRepository.getIndustryStatistics(maturity, sector, industries, year);
		List<Object []> totalAverage = industryRepository.calculateTotalAverages(maturity, sector, industries, year);
       
		double[] totalMarginWiseAverage = new double[totalAverage.get(0).length];
        for (int i = 0; i < totalAverage.get(0).length; i++) {
            totalMarginWiseAverage[i] = ((Number) totalAverage.get(0)[i]).doubleValue();
        }

        double[][] yearWiseMarginAverage = new double[yearWiseAverage.size()][];
		for (int i = 0; i < yearWiseAverage.size(); i++) {
		    Object[] rowData = yearWiseAverage.get(i);
		    double[] yearData = new double[rowData.length];
		    for (int j = 0; j < yearData.length; j++) {
		        yearData[j] = ((Number) (rowData[j])).doubleValue();
		    }
		    yearWiseMarginAverage[i] = yearData;
		}
        
        List<Metric> metrics = new ArrayList<>();

        for (int i = 0; i < metricNames.length; i++) {
            Metric metric = new Metric();
            metric.setAverage(totalMarginWiseAverage[i]);

            Map<Integer, Double> yearData = new HashMap<>();
            for (int j = 0; j < yearWiseMarginAverage.length; j++) {
                yearData.put((int) yearWiseMarginAverage[j][0], yearWiseMarginAverage[j][i+1]);
            }
            metric.setYearData(yearData);

            metrics.add(metric);
        }

        IndustryMetrics industryMetrics = new IndustryMetrics();
        
        Map<String, Metric> metricMap = new HashMap<>();
        for (int i = 0; i < metricNames.length; i++) {
            metricMap.put(metricNames[i], metrics.get(i));
        }
        industryMetrics.setIndustryName("Industry Average");
        industryMetrics.setMetrics(metricMap);

        System.out.println("Industry Metrics:");
        for (Map.Entry<String, Metric> entry : industryMetrics.getMetrics().entrySet()) {
            System.out.println("  " + entry.getKey() + ":");
            System.out.println("    Average: " + entry.getValue().getAverage());
            System.out.println("    Year Wise Data: " + entry.getValue().getYearData());
        }

        return industryMetrics;
	}		
}
