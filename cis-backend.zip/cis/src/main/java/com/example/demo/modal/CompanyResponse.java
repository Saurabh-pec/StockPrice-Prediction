package com.example.demo.modal;

import java.util.Map;

public class CompanyResponse {
	private String Company_name;
	private Map<String, CompanyMetrics> Company_metrics;
	
	public String getIndustryName() {
		return Company_name;
	}
	
	public void setIndustryName(String name) {
		this.Company_name = name;
	}
	
	public Map<String, CompanyMetrics> getMetrics() {
        return Company_metrics;
    }

    public void setMetrics(Map<String, CompanyMetrics> metrics) {
        this.Company_metrics = metrics;
    }
}
