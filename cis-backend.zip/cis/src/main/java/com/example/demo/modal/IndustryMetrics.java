package com.example.demo.modal;

import java.util.Map;

public class IndustryMetrics {
	
	private String Industry_name;
	private Map<String, Metric> Industry_metrics;
	
	public String getIndustryName() {
		return Industry_name;
	}
	
	public void setIndustryName(String name) {
		this.Industry_name = name;
	}
	
	public Map<String, Metric> getMetrics() {
        return Industry_metrics;
    }

    public void setMetrics(Map<String, Metric> metrics) {
        this.Industry_metrics = metrics;
    }
}