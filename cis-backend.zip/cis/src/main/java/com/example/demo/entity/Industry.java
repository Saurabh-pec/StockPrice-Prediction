package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "industry")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Industry {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sl_no;
	private String ticker;
	private String category;
	private String maturity;
	private String industries;
	private String sector;
	private String pricing;
	private String pricing_information;
	private int free_trial;
	private String channel;
	
	private int year;
	private float yoy_arr_growth_rate;
	private float yoy_customer_growth_rate;
	
	private String magic_no;
	private String payback_period;
	private String cac_ratio;
	
	private float net_revenue_retention;
	private float gross_margin;
	
	private String arr_per_customer;
	
	private float operating_margin;
	private float sales_marketing;
	private float fcf;
	private float arpu_growth_rate;
	private float profit_margin;
	private float yoy_net_income_growth;
	private float yoy_operating_income_growth;
}