package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.CompanyData;
import com.example.demo.modal.CompanyResponse;
import com.example.demo.modal.IndustryMetrics;
import com.example.demo.service.IndustryService;
import com.example.demo.service.CompanyService;

@RestController
@CrossOrigin("http://localhost:3000")
public class controller {
	
	@Autowired
	private IndustryService industryService;
	
	@Autowired
	private CompanyService comapnyService;
	
	@GetMapping("/iv/revenue")
	public IndustryMetrics getIndustryRevenue(
				@RequestParam(value = "maturity", required = false) List<String> maturity,
				@RequestParam(value = "sector", required = false) List<String> sector,
				@RequestParam(value = "year", required = false) List<Integer> year,
				@RequestParam(value = "industry", required = false) List<String> industries) {
		return industryService.getIndustryStatistics(maturity, sector, industries, year);
	}
	
	
	@PostMapping("/cv/revenue")
	public String InsertCompanyRevenue(@RequestBody CompanyData companyInfo) {
		return comapnyService.saveCompanyMetric(companyInfo);
	}
	
	@GetMapping("/cv/revenue")
	public CompanyResponse getCompanyRevenue(
				@RequestParam(value = "id", required = true) long code,
				@RequestParam(value = "year", required = false) List<Integer> year){
		return comapnyService.getCompanyStatistics(year, code);
	}
}























