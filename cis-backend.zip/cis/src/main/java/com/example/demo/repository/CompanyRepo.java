package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entity.Company;

public interface CompanyRepo extends JpaRepository<Company, Integer>{
	
	Optional<Company> findByCompanyCodeAndYear(long code, int year);

	@Query("SELECT c.year, c.fcf, c.revenue FROM Company c WHERE c.companyCode = :code")
	List<Object[]> findFcfByCompanyCode(@Param("code") long code);
	
	@Query("SELECT DISTINCT c.companyName FROM Company c WHERE c.companyCode = :code")
    Optional<String> findDistinctCompanyNameByCompanyCode(@Param("code") long code);
	
	@Query("SELECT " +
            "ROUND(AVG(subquery.grossMarginAverage), 2) AS totalGrossmarginAverage, " +
            "ROUND(AVG(subquery.operatingMarginAverage), 2) AS totalOperationAverage, " +
            "ROUND(AVG(subquery.profitMarginAverage), 2) AS totalProfitAverage, " +
            "ROUND(AVG(subquery.fcfMarginAverage), 2) AS totalFCF " +
        "FROM " +
            "(SELECT " +
                "c.gross_margin AS grossMarginAverage, " +
                "c.operating_margin AS operatingMarginAverage, " +
                "c.profit_margin AS profitMarginAverage, " +
                "c.fcf / c.revenue AS fcfMarginAverage " +
            "FROM " +
                "Company c " +
            "WHERE c.companyCode = :code " + 
                "AND (:year IS NULL OR c.year IN :year) " +
            "GROUP BY " +
                "c.year) AS subquery")
	List<Object[]> calculateCompanyTotalAverages(@Param("year") List<Integer> year,
	                                             @Param("code") long code);
	
	@Query("SELECT " +
	            "c.year, " +
	            "ROUND(c.gross_margin, 2) AS grossmargin_average, " +
	            "ROUND(c.operating_margin, 2) AS operatingmargin_average, " +
	            "ROUND(c.profit_margin, 2) AS profitmargin_average, " +
	            "ROUND(c.fcf / c.revenue, 2) AS fcfmargin_average " +
	        "FROM " +
	            "Company c " +
	        "WHERE c.companyCode = :code " + 
	            "AND (:year IS NULL OR c.year IN :year) " +
	        "GROUP BY " +
	            "c.year")
	List<Object[]> getCompanyStatistics(@Param("year") List<Integer> year,
	                                    @Param("code") long code);

}
