package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Company;
import com.example.demo.modal.CompanyData;
import com.example.demo.modal.CompanyMetrics;
import com.example.demo.modal.CompanyResponse;
import com.example.demo.repository.CompanyRepo;

@Service
public class CompanyService {

	@Autowired
	private CompanyRepo companyRepo;
	
	public String saveCompanyMetric(CompanyData companyInfo) {
		if(companyInfo == null) {
			return "Empty industry";
		}
		else if (companyInfo.getMarginName().equals("fcf")) {
			
            if ( companyInfo.getFinancialMetrics().get("yearData") == null || 
            	 companyInfo.getFinancialMetrics().get("revenue") == null || 
                 companyInfo.getFinancialMetrics().get("yearData").size() != 
                 companyInfo.getFinancialMetrics().get("revenue").size() ) {
                return "Invalid financial data";
            }

            for (Map.Entry<Integer, Float> entry : companyInfo.getFinancialMetrics().get("yearData").entrySet()) {
                Integer year = entry.getKey();
                Float yearValue = entry.getValue();
                Float revenue = companyInfo.getFinancialMetrics().get("revenue").get(year);

                if (revenue == null || revenue == 0) {
                    return "Invalid revenue data for year " + year;
                }

                Optional<Company> existingCompany = 
                		companyRepo.findByCompanyCodeAndYear(companyInfo.getCompanyCode(), year);
                
                if (existingCompany.isPresent()) {
                	System.out.println("update");
                	Company companyToUpdate = existingCompany.get();
                	companyToUpdate.setCompanyName(companyInfo.getCompanyName());
                	companyToUpdate.setFcf(yearValue);
                	companyToUpdate.setRevenue(revenue);
                    companyRepo.save(companyToUpdate);
                    
                    System.out.println(companyToUpdate.toString());
                } else {
                	System.out.println("new");
                    Company newCompany = new Company();
                    newCompany.setCompanyCode(companyInfo.getCompanyCode());
                    newCompany.setCompanyName(companyInfo.getCompanyName());
                    newCompany.setYear(year);
                    newCompany.setFcf(yearValue);
                    newCompany.setRevenue(revenue);
                    companyRepo.save(newCompany);
                    
                    System.out.println(newCompany.toString());
                }
                
                
                System.out.println("FCF for " + companyInfo.getCompanyName() + " in year " + year + ": " + yearValue);
            }
            return "FCF calculated successfully";
        }
		else {
			long companyCode = companyInfo.getCompanyCode();
			String companyName = companyInfo.getCompanyName();
			String marginName = companyInfo.getMarginName();
			
			Map<Integer, Float> yearData = companyInfo
											.getFinancialMetrics()
											.get("yearData");
			
			for (Map.Entry<Integer, Float> entry : yearData.entrySet()) {
	            Integer year = entry.getKey();
	            Float revenue = entry.getValue();

	            Optional<Company> existingCompany = companyRepo.findByCompanyCodeAndYear(companyCode, year);
	            if(existingCompany.isPresent()) {
	                Company companyToUpdate = existingCompany.get();
	                companyToUpdate.setCompanyName(companyName);
	                
	                switch (marginName) {
	                    case "Gross Margin":
	                        companyToUpdate.setGross_margin(revenue.floatValue());
	                        break;
	                    
	                    case "Operating Margin":
	                        companyToUpdate.setOperating_margin(revenue.floatValue());
	                        break;
	                    
	                    case "Profit Margin":
	                        companyToUpdate.setProfit_margin(revenue.floatValue());
	                        break;
	                        
	                    default:
	                        return "Unsupported margin name: " + marginName;
	                }

	                System.out.println(companyToUpdate.toString());
	                companyRepo.save(companyToUpdate);
	            } else {
	                Company company = new Company();
	                company.setCompanyCode(companyInfo.getCompanyCode());
	                company.setCompanyName(companyName);
	                company.setYear(year);

	                switch (marginName) {
	                    case "Gross Margin":
	                    	company.setGross_margin(revenue.floatValue());
	                        break;
	                    
	                    case "Operating Margin":
	                    	company.setOperating_margin(revenue.floatValue());
	                        break;
	                    
	                    case "Profit Margin":
	                    	company.setProfit_margin(revenue.floatValue());
	                        break;
	                        
	                    default:
	                        return "Unsupported margin name: " + marginName;
	                }
	                System.out.println(company.toString());
	                companyRepo.save(company);
	            }

	            System.out.println("Inserted/Updated data: Company Name - " + companyName + ", Year - " + year);
	        }
	        return "Data inserted/updated successfully";
		}
	}

	public CompanyResponse getCompanyStatistics(List<Integer> year, long code) {
		String[] metricNames = { "Gross Margin", "Operating Margin", "Profit Margin", "fcf" };
		List<Object []> yearWiseAverage = companyRepo.getCompanyStatistics(year, code);
		List<Object []> totalAverage = companyRepo.calculateCompanyTotalAverages(year, code);

		double[] totalMarginWiseAverage = new double[totalAverage.get(0).length];
        for (int i = 0; i < totalAverage.get(0).length; i++) {
            totalMarginWiseAverage[i] = ((Number) totalAverage.get(0)[i]).doubleValue();
        }

        double[][] yearWiseMarginAverage = new double[yearWiseAverage.size()][];
		for (int i = 0; i < yearWiseAverage.size(); i++) {
		    Object[] rowData = yearWiseAverage.get(i);
		    double[] yearData = new double[rowData.length];
		    for (int j = 0; j < yearData.length; j++) {
		        yearData[j] = ((Number) (rowData[j])).doubleValue();
		    }
		    yearWiseMarginAverage[i] = yearData;
		}
		
		List<CompanyMetrics> companyMetrics = new ArrayList<>();

        for (int i = 0; i < metricNames.length; i++) {
        	CompanyMetrics metric = new CompanyMetrics();
            metric.setAverage(totalMarginWiseAverage[i]);

            Map<Integer, Double> yearData = new HashMap<>();
            for (int j = 0; j < yearWiseMarginAverage.length; j++) {
                yearData.put((int) yearWiseMarginAverage[j][0], yearWiseMarginAverage[j][i+1]);
            }
            
            Map<String, Map<Integer, Double>> financialMetricsMap = new HashMap<>();
            financialMetricsMap.put("yearData", yearData);
            
            if(metricNames.length-1 == i) {
            	List<Object []> fcfRevenue = companyRepo.findFcfByCompanyCode(code);
                
                double[][] fcfRevenueyearWise = new double[fcfRevenue.size()][];
        		for (int k = 0; k < fcfRevenue.size(); k++) {
        		    Object[] rowData = fcfRevenue.get(k);
        		    double[] yearDatafcf = new double[rowData.length];
        		    for (int j = 0; j < yearDatafcf.length; j++) {
        		    	yearDatafcf[j] = ((Number) (rowData[j])).doubleValue();
        		    }
        		    fcfRevenueyearWise[k] = yearDatafcf;
        		}
        		
        		String[] arr = {"fcf", "revenue"};
                for(int k=0; k<2; k++) {
                    Map<Integer, Double> yearDatafcf = new HashMap<>();
                    for (int j = 0; j < fcfRevenueyearWise.length; j++) {
                    	yearDatafcf.put((int) fcfRevenueyearWise[j][0], fcfRevenueyearWise[j][k+1]);
                    }
                    Map<String, Map<Integer, Double>> fcfRevenueMap = new HashMap<>();
                    financialMetricsMap.put(arr[k], yearDatafcf);
                }
            }
            
            metric.setFinancialMetrics(financialMetricsMap);  
            companyMetrics.add(metric);
        }
        
		CompanyResponse companyResponse = new CompanyResponse();  
        Map<String, CompanyMetrics> metricMap = new HashMap<>();
        for (int i = 0; i < metricNames.length; i++) {
            metricMap.put(metricNames[i], companyMetrics.get(i));
        }

        String name = companyRepo.findDistinctCompanyNameByCompanyCode(code).orElse(null);
        companyResponse.setIndustryName(name);
        companyResponse.setMetrics(metricMap);
		        
		return companyResponse;
	}
}
